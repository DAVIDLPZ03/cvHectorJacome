<?php
require '../db.php';

$result = $conn->query("SELECT * FROM items");
$items = [];

while ($row = $result->fetch_assoc()) {
    $row['archivo_url'] = $row['archivo'] ? "http://localhost/api-rest/api/upload/" . $row['archivo'] : null;
    $items[] = $row;
}

echo json_encode($items);
?>