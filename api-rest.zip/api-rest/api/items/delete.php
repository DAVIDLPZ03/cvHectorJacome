<?php
require '../db.php';

$id = $_POST['id'] ?? 0;

$result = $conn->query("SELECT archivo FROM items WHERE id = $id");
$row = $result->fetch_assoc();
if ($row && $row['archivo']) {
    $ruta = "../upload/" . $row['archivo'];
    if (file_exists($ruta)) {
        unlink($ruta);
    }
}

$stmt = $conn->prepare("DELETE FROM items WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();

echo json_encode(["success" => true]);
?>