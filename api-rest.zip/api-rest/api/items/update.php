<?php
require '../db.php';

$id = $_POST['id'] ?? 0;
$nombre = $_POST['nombre'] ?? '';
$descripcion = $_POST['descripcion'] ?? '';
$archivoNombre = '';

if (isset($_FILES['archivo']) && $_FILES['archivo']['error'] === UPLOAD_ERR_OK) {
    $archivo = $_FILES['archivo'];
    $archivoNombre = time() . "_" . basename($archivo['name']);
    move_uploaded_file($archivo['tmp_name'], '../upload/' . $archivoNombre);
}

if ($archivoNombre) {
    $stmt = $conn->prepare("UPDATE items SET nombre = ?, descripcion = ?, archivo = ? WHERE id = ?");
    $stmt->bind_param("sssi", $nombre, $descripcion, $archivoNombre, $id);
} else {
    $stmt = $conn->prepare("UPDATE items SET nombre = ?, descripcion = ? WHERE id = ?");
    $stmt->bind_param("ssi", $nombre, $descripcion, $id);
}

$stmt->execute();
echo json_encode(["success" => true]);
?>