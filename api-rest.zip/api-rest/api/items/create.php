<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
require '../db.php';

$nombre = $_POST['nombre'] ?? '';
$descripcion = $_POST['descripcion'] ?? '';
$archivoNombre = '';

if (isset($_FILES['archivo']) && $_FILES['archivo']['error'] === UPLOAD_ERR_OK) {
    $archivo = $_FILES['archivo'];
    $archivoNombre = time() . "_" . basename($archivo['name']);
    move_uploaded_file($archivo['tmp_name'], '../upload/' . $archivoNombre);
}

$stmt = $conn->prepare("INSERT INTO items (nombre, descripcion, archivo) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $nombre, $descripcion, $archivoNombre);
$stmt->execute();

echo json_encode(["success" => true, "id" => $stmt->insert_id]);
?>